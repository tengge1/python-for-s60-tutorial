'''cl_gui模块用法
静态隐性双行列表
陆楚良
QQ：519998338(若加好友请写验证信息！)'''


import appuifw
import e32
import cl_gui
import globalui
lock=e32.Ao_lock()

def cn(x):return x.decode('utf-8')
appuifw.app.screen='full'


list=[
    (cn('关于'),cn(cl_gui.__doc__)),
    (cn('鸣谢'),cn('感谢您对在下的支持，祝您对pys60的研究一路顺风！')),
    (cn('菜单三'),cn('隐藏内容三')),
    (cn('菜单四'),cn('隐藏内容四')),
    (cn('菜单五'),cn('隐藏内容五')),
    (cn('菜单六'),cn('隐藏内容六')),
    (cn('菜单七'),cn('隐藏内容七')),
    (cn('菜单八'),cn('隐藏内容八')),
    (cn('菜单九'),cn('隐藏内容九')),
    (cn('菜单十'),cn('隐藏内容十')),
    (cn('菜单十一'),cn('隐藏内容十一')),
    (cn('菜单十二'),cn('隐藏内容十二')),
    (cn('菜单十三'),cn('隐藏内容十三')),
    (cn('菜单十四'),cn('隐藏内容十四')),
]
#请注意好列表规则哦！它可跟框架的款式有密切关系哦


def press():
    #按下确定键后该函数将被运行
    
    index=Listbox.current()
    #通过current函数获取当前被选中的值
    
    globalui.global_msg_query(Listbox.list[index][1],Listbox.list[index][0])


def move():
    #列表发生变化后该函数将会被运行
    pass



Listbox=cl_gui.Listbox2(list,press,move_callback=move)
#move_callback为可选参数，这里写只是为了让大家知道怎么用而已！

appuifw.app.body=Listbox

e32.ao_sleep(1)
#延迟一下让你看到后面修改的效果

Listbox.color['TitleFont']=0xff0000
#修改标题字体颜色

#Listbox.strftime='%Y-%m-%d %H:%M'
#修改时间格式

#Listbox.TitlePaneUi='small'
#修改标题面板

Listbox.redraw()
#刷新屏幕



def find():
    t=appuifw.query(cn('请输入：'),'text')
    if t==None:return
    a=Listbox.find(t,find=0,keywords=1,ignorecase=1,skip=1)
    if a==-1:
        appuifw.note(cn('未找到'),'error')
    else:
        appuifw.note(cn('位置：%s')%a,'conf')

def set():
    t=appuifw.query(cn('请输入：'),'number')
    if t==None:return
    try:
        Listbox.set_list(Listbox.list,t)
    except:
        appuifw.note(cn('输入有误或超出规定范围'),'error')

def screen(n):
    appuifw.app.screen=n
    Listbox.redraw()
    #可以忽略刷新屏幕，不过为避免可能发生一些问题，建议还是写上！

def titlepaneui(n):
    Listbox.TitlePaneUi=n
    Listbox.redraw()
    #强烈建议刷新屏幕，不然界面不能及时变化

def left_right(n):
    L,R=Listbox.set_text()
    if n==3000:t=L
    if n==3009:t=R
    s=appuifw.query(cn('请输入'),'text',t)
    if s==None:return
    Listbox.set_text(s,n)

appuifw.app.menu=[
    (cn('查找'),find),
    (cn('定位'),set),
    (cn('切换屏幕'),(
        (cn('标准'),lambda:screen('normal')),
        (cn('中屏'),lambda:screen('large')),
        (cn('全屏'),lambda:screen('full'))
    )),
    (cn('标题面板'),(
        (cn('小面板'),lambda:titlepaneui('small')),
        (cn('标准'),lambda:titlepaneui('normal'))
    )),
    (cn('左右键'),(
        (cn('左键名'),lambda:left_right(3000)),
        (cn('右键名'),lambda:left_right(3009))
    ))
]

Listbox.bind(63495,lambda:Listbox.set_move(-1))
Listbox.bind(63496,lambda:Listbox.set_move(1))

#bind2按键绑定示例：
Listbox.bind2(50,lambda:Listbox.set_move(-2),1)
#绑定2键为上一菜单，长按属性
Listbox.bind2(56,lambda:Listbox.set_move(2),1)
#绑定8键为下一菜单，长按属性
Listbox.bind2(52,lambda:Listbox.set_move(-1),1)
#绑定4键为上一页，长按属性
Listbox.bind2(54,lambda:Listbox.set_move(1),1)
#绑定6键为下一页，长按属性
Listbox.bind2(53,press,3)
#绑定5键为确认，按下属性

def exit():
    global run
    run=0
    appuifw.app.set_exit()
appuifw.app.exit_key_handler = exit
run=1
while run:
    e32.ao_sleep(0)
    Listbox.running()
    #如果菜单文字过长，running函数被执行一次，文字将滚动一次，使用死循环是为了让其无限滚动！