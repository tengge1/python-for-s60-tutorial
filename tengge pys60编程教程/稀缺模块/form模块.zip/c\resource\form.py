#阿高版权所有
#转载请注明作者
#用法↓
#import form
#form=form.form()
#showtime=5
#x=20
#y=220
#caption="标题".decode("utf-8")
#data="内容[作者，阿高]".decode("utf-8")
#QQface=1#QQ表情 1表示大笑，一共支持27个QQ表情
#form.caption(showtime,x,y,caption,data,QQface)

class form:
    def caption(self,showtime,sx,sy,Caption,Data,num):
        def cn(x):
            return x.decode("utf-8")
        import TopWindow,graphics,e32,appuifw,audio
        q1=graphics.Image.open("c:\\resource\\1.png")
        q2=graphics.Image.open("c:\\resource\\2.png")
        q2x,q2y=q2.size
        q2=graphics.Image.new((q2x,q2y),"1")
        q2.load("c:\\resource\\2.png")
        try:
            sound=audio.Sound.open("c:\\resource\\gaosound.rng")
        except:
            pass
        img=graphics.screenshot()
        x,y=img.size
        x1=x-40
        y1=y-x
        font=(None,None,graphics.FONT_BOLD)
        screen=TopWindow.TopWindow()        
        a=graphics.Image.new((x,y))
        a.rectangle((0,0,x1,y1-60),0x316ac5,0x316ac5)#0xc864ff
        a.rectangle((0,y1-60,x1,y1),0xc864ff,0xc864ff)        
        a.text((0,18),Caption,0xffffff,font=("normal",15))
        l = len(Data)
        if l==13 or l <13:
            a.text((2,40),Data,0xffffff,font=("normal",15))
        if l>13 or l ==26  or l>26:
            data=Data[0:13]
            a.text((2,40),data,0xffffff,font=("normal",15))
            Data=Data[l-4:l]
            a.text((2,65),cn("……")+Data,0xffffff,font=("normal",15))        
        screen.add_image(a,(0,0,x,y))
        screen.size=(x1,y1)
        screen.position=(sx,sy)
        
        fx=25
        fy=26
        if num==1:
            s=(0,0,fx,fy)#大笑
            a.blit(q1,target=(170,50),source=s,mask=q2)
        elif num==2:
            s=(fx,0,fx*2,fy)#吐舌头
            a.blit(q1,target=(170,50),source=s,mask=q2)
        elif num==3:
            s=(fx*2+4,0,fx*3+4,fy)#冒汗
            a.blit(q1,target=(170,50),source=s,mask=q2)
        elif num==4:
            s=(fx*2+26,0,fx*4+5,fy)#偷笑
            a.blit(q1,target=(170,50),source=s,mask=q2)
        elif num==5:
            s=(fx*4+5,0,fx*4+30,fy)#88
            a.blit(q1,target=(170,50),source=s,mask=q2)
        elif num==6:
            s=(fx*4+30,0,fx*4+55,fy)#打头
            a.blit(q1,target=(170,50),source=s,mask=q2)
        elif num==7:
            s=(fx*4+56,0,fx*4+85,fy)#流汗
            a.blit(q1,target=(170,50),source=s,mask=q2)
        elif num==8:
            s=(fx*4+85,0,fx*4+85+fx,fy)#猪头
            a.blit(q1,target=(170,50),source=s,mask=q2)
        elif num==9:
            s=(fx*4+85+fx,0,fx*4+85+fx*2,fy)#花
            a.blit(q1,target=(170,50),source=s,mask=q2)
        elif num==10:
            s=(0,fy,fx,fy*2)#流泪
            a.blit(q1,target=(170,50),source=s,mask=q2)
        elif num==11:
            s=(fx,fy,fx*2,fy*2)#大哭
            a.blit(q1,target=(170,50),source=s,mask=q2)
        elif num==12:
            s=(fx*2,fy,fx*3,fy*2)#嘘            
            a.blit(q1,target=(170,50),source=s,mask=q2)
        elif num==13:
            s=(fx*3+5,fy+2,fx*4+5,fy*2)#酷
            a.blit(q1,target=(170,50),source=s,mask=q2)
        elif num==14:
            s=(fx*4+5,fy+2,fx*5+5,fy*2)#疯狂
            a.blit(q1,target=(170,50),source=s,mask=q2)
        elif num==15:
            s=(fx*5+5,fy,fx*6+5,fy*2)#想死
            a.blit(q1,target=(170,50),source=s,mask=q2)
        elif num==16:
            s=(fx*6+10,fy,fx*7+10,fy*2)#死
            a.blit(q1,target=(170,50),source=s,mask=q2)
        elif num==17:
            s=(fx*7+10,fy,fx*8+10,fy*2)#炸弹
            a.blit(q1,target=(170,50),source=s,mask=q2)
        elif num==18:
            s=(fx*8+10,fy,fx*9+10,fy*2)#大刀
            a.blit(q1,target=(170,50),source=s,mask=q2)
        elif num==19:
            s=(0,fy*2,fx,fy*4-15)#可爱
            a.blit(q1,target=(170,50),source=s,mask=q2)

        elif num==20:
            s=(fx,fy*2,fx*2,fy*4-15)#色
            a.blit(q1,target=(170,50),source=s,mask=q2)                                
        elif num==21:
            s=(fx*2,fy*2,fx*3,fy*4-15)#丑
            a.blit(q1,target=(170,50),source=s,mask=q2)
        elif num==22:
            s=(fx*3+5,fy*2,fx*4+5,fy*4-15)#寸
            a.blit(q1,target=(170,50),source=s,mask=q2)
        elif num==23:
            s=(fx*4+5,fy*2,fx*5+5,fy*4-15)#吐
            a.blit(q1,target=(170,50),source=s,mask=q2)
        elif num==24:
            s=(fx*5+5+4,fy*2+2,fx*6+5+4,fy*4-15)#微笑
            a.blit(q1,target=(170,50),source=s,mask=q2)
        elif num==25:
            s=(fx*6+8,fy*2+1,fx*7+8,fy*4-15)#火
            a.blit(q1,target=(170,50),source=s,mask=q2)
        elif num==26:
            s=(fx*7+10+3,fy*2,fx*8+10+3,fy*4-15)#监介
            a.blit(q1,target=(170,50),source=s,mask=q2)
        elif num==27:
            s=(fx*8+10,fy*2,fx*9+10,fy*4-15)#惊恐
            a.blit(q1,target=(170,50),source=s,mask=q2)
            
        try:
            sound.play()
        except:
            pass    
        screen.show()
        e32.ao_sleep(showtime)
        for i in range(sx):
            i=sx+i
            screen.position=(i,sy)
            
            
         