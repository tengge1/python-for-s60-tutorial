# by 飞影7610
# feiying7610@yeah.net
# QQ: 654709957
# http://wapele.cn

import e32
import appuifw
import fy_menu

def quit(show=False):
  if show:
    return True
  ao_lock.signal()

def full(show=False):
  if show:
    return appuifw.app.screen != 'full' #(注：条件为真时显示该菜单选项)
  appuifw.app.screen = 'full'
def large(show=False):
  if show:
    return appuifw.app.screen != 'large'
  appuifw.app.screen='large'
def normal(show=False):
  if show:
    return appuifw.app.screen != 'normal'
  appuifw.app.screen = 'normal'

def about(str='fy_menu',show=False):
  if val: # val值是判断在菜单项目中显示与否(可以用全局变量，类属性等来判断。注：返回False时不显示该菜单选项)
    return False
  if appuifw.app.screen == 'full': # 还可以增加断断
    return False
  if show: # 每个在菜单中的选项对应的函数(或方法)里必须有show形参和这句判断语句(注意：所有形参都要有默认值)
    return True
  appuifw.note((str+' by 飞影7610\n').decode('utf8'))

def file2(): #文件菜单
  menu.up_sink('blue') #更换菜单主题
  menu.show((
    ('1','编辑', 49, (edit, True)),
    ('2','全屏', 50, full),
    ('3','大屏', 51, large),
    ('4','小屏', 52, normal),
      ))

def edit(): #编辑菜单
  menu.up_sink('pink')
  menu.show((
    ('1','标记', 49, (mark, True)),
    ('2','全屏', 50, full),
    ('3','大屏', 51, large),
    ('4','小屏', 52, normal),
      ))

def mark(): #标记菜单
  menu.up_sink('black')
  menu.show((
    ('1','关于', 49, about),
    ('2','全屏', 50, full),
    ('3','大屏', 51, large),
    ('4','小屏', 52, normal),
      ))

def exit(): #退出菜单
  menu.up_sink('grey')
  menu.target = (-2, -2)
  menu.show((
    ('1','退出程序', 49, quit),
    ('2','退出程序', 50, quit),
    ('3','退出程序', 51, quit),
    ('4','退出程序', 52, quit)))
  menu.target = (2, -2) #还原初始坐标

def mian(): #�����菜单
  menu.up_sink('grey') #更换菜单主题
  menu.show((
    ('1','文件', 49, (file2, True)),
    ('2','编辑', 50, (edit, True)), # 条件为True时显示选项
    ('3','编辑', 51, (edit, False)), # 条件为False时不显示选项
    ('4','标记', 52, (mark, True)),
    ('5','全屏', 53, full),
    ('6','大屏', 54, large),
    ('7','小屏', 55, normal),
    ('8','关于', 56, about),
    ('9','关于', 57, about),
    ('0','文件', 48, (file2, True)),
    ))

appuifw.app.title = 'fy_menu 示例程序\n by 飞影7610'.decode('utf8')
#appuifw.app.menu = [('退出'.decode('utf8'), quit)]
appuifw.app.screen = 'full'
appuifw.app.exit_key_handler = exit
appuifw.app.body = text = appuifw.Text()
text.bind(63586, mian) #绑定通话键
text.bind(63499, mark) #绑定笔键

text.add('fy_menu by 飞影7610\nfy_menu模块介绍：\n支持多级菜单\n支持全选项快捷键\n菜单框自适屏(切换大小屏试试)\n支持自定义菜单框坐标\n支持自定义字体\n支持更换主题(内置4款)\n支持S60一二三版机型\n      ---此示例程序说明---\n按通话键 - 调出主菜单示例\n按笔形键 - 调出标记菜单示例\n按右软键 - 调出退出菜单示例'.decode('utf8'))
#text.set_pos(0)

val = False
menu = fy_menu.Menu()
#menu = fy_menu.Menu(font=u'CombinedChinesePlain16', sink='grey') #定义字体、主题
menu.target = (2, -2) # 自定义主菜单坐标值 或 (2, 2) 或 (-2, 2) 或 (-2, -2) 或 (8, -8)都可以。
ao_lock = e32.Ao_lock()
ao_lock.wait()
