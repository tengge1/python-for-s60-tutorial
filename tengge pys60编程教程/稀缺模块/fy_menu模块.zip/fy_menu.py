__doc__="""
fy_menu v1.2
        by 飞影7610
邮箱: feiying7610@yeah.net
QQ: 654709957
http://wapele.cn
未经同意不得修改模块
请勿将模块用于商业用途
不得将模块进行加密编译
        2010年6月24日
""".decode('utf8')

class Main(object):
  number = 0
  def __init__(self, MenuTarget, **keys):
    if Main.number == 20:
      raise 'error: Main.number > 20'
    Main.number += 1
    self.__dict__.update(keys)
    self._while = False
    import e32
    from graphics import Image
    self.E = e32
    self.I = Image
    self._tup_list = []
    self._show_list = []
    def quit(call):
       self.close_window()
       call()
    def one(call):
      return lambda: quit(call)
    def set_index(name):
      self.set_index(*self.get_index([i[0] for i in self._list], self._list_len, name, lowers=None))
      self.r_full()
      self.ok(False) #self.go()
    def two(info):
      return lambda: set_index(info)
    TUPLE = False
    p = 0
    self._keys_dict = {}
    for info, title, keys, call in self._list:
      if type(call) is tuple:
        TUPLE = True
        tup, show = True, call[1]
      else:
        tup, show = False, call(show=True)
      if show:
        self._show_list.append(p)
        if tup:
          self._keys_dict[keys] = (0, two(info), 0, 0)
        else:
          self._keys_dict[keys] = (0, one(call), 0, 0)
      self._tup_list.append((tup, show))
      p += 1
    self._list_len = len(self._list)
    zw, zh = self._canvas.size
    w = max([self._img.measure_text(i[1].decode('utf8'),font=self._font)[1] for i in self._list]) + self._c_h + 4
    if TUPLE:
      w += self._c_h/2
    if w > zw:
      w = zw - 4
    a, b = MenuTarget
    c, d = 0, 0
    if a < 0:
      a = -a
      c += 1
    if b < 0:
      b = -b
      d += 1
    h = (zh-6-b)/self._c_h
    if h < 1:
      raise 'error: target'
    if h < self._list_len:
      w += 4
    else:
      h = self._list_len
    self._lines = h
    h *= self._c_h
    h += 4
    if Main.number < 2:
      if c:
        a = zw - w - a
        if a < 2:
          a = 2
      if d:
        b = zh - h - b
      self._target = (a, b)
    else:
      x, y = self._target
      if x+w+2 > zw:
        x -= (x+w+2 - zw)
      if y+h+b + (Main.number-1)*2 > zh:
        y -= (y+h+b + (Main.number-1)*2 - zh)
        if y < 2:
          y = 2
      self._target = (x, y)
    self._img = self.I.new((w, h))
    x, y = w - 1, h - 1
    self._JT_R = x
    self.blit_line = lambda: self._img.line((0,0, x,0, x,y, 0,y, 0,0), 0x000000)

    self._tuples = tuple(range(self._lines))
    self._p_body = {
      'line_p1': 2,
      'j_L': self._JT_R - 4,
      'j_h': float(self._lines * self._c_h),
      'j_m': (self._lines * self._c_h) * (self._lines - 1),
      }
    self.set_index()
    R = self._JT_R
    if not self._JT: R -= 1
    self._p_current = {}
    for i in range(self._lines):
      val = (self._c_h * i)+2
      self._p_current[i] = (2, val, R, val + self._c_h)
    if self._index not in self._show_list:
      if self._show_list:
        self.down()
      else:
        self._current = -1
    self.r_full()

  #def go(self): self.ok(False)
  def ok(self, ok=True):
    date = self._list[self._index][3]
    if type(date) is tuple:
      date[0]()
    elif ok:
      self.close_window()
      date()
  def back(self):
    if Main.number > 1:
      number = Main.number
      Main.number = 0
      self.close_window()
      Main.number = number - 1

  def get_target(self):
    return (self._target[0]+self._img.size[0]-(3, 7)[self._JT != False],
      self._target[1]+3+self._current*self._c_h)

  def r_2(self, old):
    self.r_main((old, self._current), True)

  def r_full(self):
    self._img.clear(self._sink[0])
    self.r_main(self._tuples)

  def r_main(self, tuples, r_2=None):
    sink_clear, sink_title, sink_current, sink_f1, sink_f2, sink_f3 = self._sink
    t_down = self._t_down
    for p in tuples:
      index = p + self._Dm1
      try:
        info, title, keys, call = self._list[index]
      except IndexError:
        break
      p_c = self._p_current[p]
      tup, show = self._tup_list[index]
      if p == self._current:
        t_fill, r_fill = sink_f2, sink_current
        self._img.rectangle(p_c, fill=r_fill)
      else:
        r_fill = sink_clear
        if show:
          t_fill = sink_f1
        else:
          t_fill = sink_f3
        if r_2:
          self._img.rectangle(p_c, fill=r_fill)
      p_t = p_c[1] + t_down
      self._img.text((6, p_t), info.decode('utf8'), t_fill, self._font)
      self._img.text((self._c_h, p_t), title.decode('utf8'), t_fill, self._font)
      if tup:
        bc = self._c_h/2 - 2
        p1x = self._JT_R - bc-3
        if self._JT:
          p1x -= 4
        p_c0, p_c1, p_c2, p_c3 = p_c
        self._img.rectangle((p1x-2, p_c1, p_c2, p_c3), fill=r_fill)
        p2x = p1x + bc
        p1y = p_c[1] + 2
        p2y = p1y + bc
        self._img.polygon((p1x, p1y, p2x, p2y, p1x, p2y+bc), *(show and (0, 0xffff55) or (t_fill, r_fill)))
    if self._JT:
      j_p = self._Dm1 * self._Jb + self._p_body['line_p1']
      self._img.rectangle( (self._p_body['j_L'], j_p, self._JT_R, j_p + self._JT), fill=self._sink[1])
    self.blit_line()
    self._canvas.blit(self._img, target=self._target)

  def get_index(self, LT, Ll, name, lowers=True):
    index_tuple = (0, 0, 0)
    index = 0
    try:
      if name:
        if lowers:
          index = [i.lower() for i in LT].index(name.lower())
        else:
          index = LT.index(name)
    except ValueError:
      pass
    else:
      if index:
        if not Ll > self._lines:
          index_tuple = (index, 0, index)
        else:
          Dm1 = index  - (self._lines-2)
          if Dm1 < 1:
            index_tuple = (index, 0, index)
          elif index > Ll - self._lines:
            Dm1 = Ll - self._lines
            index_tuple = (index - Dm1, Dm1, index)
          else:
            index_tuple = (self._lines-2, Dm1, index)
    return index_tuple

  def close(self):
    self._img = None
    self.__dict__.clear()

  def set_index(self, current=0, Dm1=0, index=0):
    self._current, self._Dm1, self._index = current , Dm1,index
    if self._list_len  > self._lines:
      self._Dm2 = self._list_len - self._lines
      self._JT = self._p_body['j_m'] / self._list_len + self._c_h
      self._Jb = (self._p_body['j_h'] - self._JT) / self._Dm2
    else:
      self._Dm2 = 0
      self._JT = False

  def get_keys_dict(self):
    if not self._show_list:
      return {165: (0, self.close_window, 0, 0),
      14: (0, self.back, 0, 0)}
    keys = {
      42: (0, self.up_page, self.up_end, 0),
      127: (0, self.down_page, self.down_end, 0),
      }
    keys.update(self._keys_dict)
    keys.update({
      165: (0, self.close_window, 0, 0),
      14: (0, self.back, 0, 0),
      #15: (0, self.go, 0, 0),
      15: (0, lambda: self.ok(False), 0, 0),
      16: (self.up, 0, lambda: self.while_call(self.up), self.stop),
      17: (self.down, 0, lambda: self.while_call(self.down), self.stop),
      164: (0, self.ok, 0, 0),
      167: (0, self.ok, 0, 0),
      })
    return keys

  def stop(self):
    self._while = False

  def while_call(self, call):
    self._while = True
    while self._while:
      call()
      self.E.ao_sleep(.025)

  def up(self):
    ct, Dm1 = self._current, self._Dm1
    show = True
    while True:
      if self._current == 0:
        if self._while: #停止长按
          self._while = False
          show = False
          break
        self._Dm1 = self._Dm2
        self._index = self._list_len - 1
        self._current = self._JT and (self._lines - 1) or self._index
      elif self._current == 1:
        if self._index == 1:
          self._index -= 1
          self._current -= 1
        else:
          self._index -= 1
          self._Dm1 -= 1
      else:
        self._index -= 1
        self._current -= 1
      if self._index in self._show_list:
        break
    if show:
      if Dm1 == self._Dm1:
        self.r_2(ct)
      else:
        self.r_full()

  def down(self):
    ct, Dm1 = self._current, self._Dm1
    show = True
    while True:
      if self._current == self._lines - 1:
        if self._while:
          self._while = False
          show = False
          break
        self._Dm1 = self._current = self._index = 0
      elif self._current == self._lines - 2:
        if self._list_len - self._index == 2:
          self._index += 1
          self._current += 1
        else:
          self._index += 1
          self._Dm1 += 1
      else:
        self._index += 1
        self._current += 1
      if self._index in self._show_list:
        break
    if show:
      if Dm1 == self._Dm1:
        self.r_2(ct)
      else:
        self.r_full()

  def page_end(self, index):
    if self._index not in self._show_list:
      if self._index < self._show_list[index]:
        self.down()
      else:
        self.up()

  def up_page(self):
    if self._JT:
      if self._current == self._lines - 1:
        self._index -= 1
        self._current -= 1
      self._Dm1 -= self._lines
      self._index -= self._lines
      if self._Dm1 < 0 or self._index < 0:
        self._current = self._index = self._Dm1 = 0
      self.r_full()
      self.page_end(0)
    else:
      self.up_end()

  def up_end(self):
    self._current = self._index = self._Dm1 = 0
    self.r_full()
    self.page_end(0)

  def down_page(self):
    if self._JT:
      if self._current == 0:
        self._index += 1
        self._current += 1
      self._Dm1 += self._lines
      self._index += self._lines
      if self._Dm1 > self._Dm2 or self._index >= self._list_len:
        self._Dm1 = self._Dm2
        self._index = self._list_len - 1
        self._current = self._lines - 1
      self.r_full()
      self.page_end(1)
    else:
      self.down_end()

  def down_end(self):
    self._index = self._list_len - 1
    if self._JT:
      self._Dm1 = self._Dm2
      self._current = self._lines - 1
    else:
      self._current = self._index
    self.r_full()
    self.page_end(1)


class Menu(object):
  def __init__(self,font=u'LatinBold12', sink='grey', **keys):
    import os
    import e32
    import appuifw
    self.O = os
    self.E = e32
    self.A = appuifw
    from graphics import Image
    self._lock = self.E.Ao_lock()

    self._keys_dict, self._keys_type1, self._keys_type2 = ({}, 2, 165)
    self._object = []
    self._api = 2
    self._canvas = self.A.Canvas(redraw_callback=self.redraw, event_callback=self.event)
    body = self.A.app.body
    self.A.app.body = self._canvas
    self.A.app.body = body

    if font not in (self.A.available_fonts()+['dense']):
      font = 'dense'
    self._img = Image.new((120,60))
    text = []
    pos=[(i, 28) for i in xrange(0, 28)]
    for i in (font,'dense'):
      self._font = i
      self._img.clear(0)
      color = self._img.getpixel((0,0))
      self._img.text(pos, '国'.decode('utf8'), 0xffffff, i)
      for p in xrange(28):
        if self._img.getpixel((16,p)) != color:
          text.append(p)
          break
      else:
        continue
      break

    for p in xrange(p+1, p+28):
      if self._img.getpixel((16, p)) == color:
        text.append(p)
        break
    self._img = Image.new((0,0))
    c_h = text[1]-text[0]
    t_down = (28 + c_h)-text[1]
    if c_h < 12:
      t_down += (12-c_h+1)/2
      c_h = 12
    self._font = font
    self._c_h = c_h + 4
    self._t_down = t_down + 2
    self.up_sink(sink)
    self.target = (2, -2)


  def event(self, d):
    try:
      c0, c1, c2, c3 = self._keys_dict[d['scancode']]
    except KeyError:
      pass
    else:
      if self._keys_type1 == 2 and self._keys_type2 != d['scancode']:
          return
      if d['type'] == 3:
        self._keys_type1 = 1
        self._keys_type2 = d['scancode']
        if c0: c0()
        self.E.ao_sleep(0.25)
        if self._keys_type1 == 1:
          self._keys_type1 = 2
          if c2:
            if not c3:
              self._keys_type1 = 0
            c2()
      elif d['type'] == 2:
        if self._keys_type1 == 1:
          self._keys_type1 = 0
          if c1: c1()
        elif self._keys_type1 == 2:
          self._keys_type1 = 0
          if c3: c3()

  def redraw(self, source=None):
    self._api += 1
    if self._api == 1:
      def api():
        self.A.app.body = self._old[0]
        #self.E.ao_yield()
        self.A.app.body = self._canvas
      self.E.ao_sleep(0, api)
    elif self._api == 2:
      self._api = 0
      for obj in self._object:
        self._canvas.blit(obj._img, target=obj._target)


  def show(self, list):
    if Main.number:
      return self.menu(list)
    self._old = (
      self.A.app.body,
      self.A.app.menu,
      self.A.app.focus,
      self.A.app.exit_key_handler,
      )
    self._api = 2
    (self.A.app.body,
      self.A.app.menu,
      self.A.app.focus,
      self.A.app.exit_key_handler,
      ) = self._canvas, [], None, lambda: None

    def api():
      self._api = 0
    self.E.ao_sleep(0, api)
    self._keys_type1 = 0
    self.menu(list)
    del list
    self._lock.wait()
    (self.A.app.body,
      self.A.app.menu,
      self.A.app.focus,
      self.A.app.exit_key_handler,
      ) = self._old
    self._old = None


  def close_window(self):
    Main.number -= 1
    del self._object[-1]
    try:
      self.window.close()
      self.window = None
    except AttributeError:
      pass
    self._keys_dict.clear()
    if Main.number > 0:
      self.close_window()
    elif Main.number == 0:
      self._lock.signal()
    else: # Main.number < 0
      self.window = self._object[-1]
      self._keys_dict.update(self.window.get_keys_dict())
      self.redraw()
      self.E.ao_yield()

  def menu(self, list):
    if not list:
      raise 'error: len(list) < 1'
    self.window = Main(
      self.target,
      _target = Main.number and self.window.get_target() or self.target,
      _list = list,
      _img = self._img,
      _canvas = self._canvas,
      _font = self._font,
      _c_h = self._c_h,
      _t_down = self._t_down,
      _sink = self._sink,
      close_window = self.close_window,
      )
    self._object.append(self.window)
    self._keys_dict.clear()
    self._keys_dict.update(self.window.get_keys_dict())


  def up_sink(self,sink='grey'):
    if sink=='blue': # 蓝色
      self._sink = (0x8080ee, 0xeeeeee, 0x5050aa, 0x000000, 0xffffff, 0xa0a0f0, )
    elif sink == 'black': #黑
      self._sink = (0x303030, 0x55ee55, 0xdddddd, 0xbbbbbb, 0, 0x505050, )
    elif sink == 'pink': #粉红
      self._sink = (0xffafbf, 0x0000ff, 0xef3030, 0x333333, 0xffffff, 0xffcfe0, )
    else: #灰色
      self._sink = (0xc6c6c6, 0x2020ff, 0x666666, 0, 0xffffff, 0xeeeeee)


if __name__ == '__main__':
  from appuifw import note
  def about(show=False):
    if val:
      return False # True - show , False - hide
    if show:
      return True # True - show , False - hide
    note('fy_menu v1.0 by 飞影7610'.decode('utf8'))
  def m(two=False):
    menu.show((
      ('1','文件', 49, (m, two)), # True - show
      ('2','编辑', 50, (m, val and two)), # False - hide
      ('3','关于', 51, about),
      ))

  val = False
  menu = Menu()
  menu.target = (2, -2) # or (2, 2)
  m(True)
  menu.up_sink('blue') # or 'black' or 'pink'
  val = True
  menu.target = (-2, -2) # or (-2, 2)
  m(True)
