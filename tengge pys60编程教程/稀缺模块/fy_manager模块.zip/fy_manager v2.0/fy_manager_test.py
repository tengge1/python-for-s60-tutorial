# by飞影7610
# wapele.cn

import appuifw
import e32
import fy_manager

fy_manager.Manager.workdir = [] #初始化工作目录(必要，否则旧版本时将异常，除非不增加工作目录)

fy_manager.Manager.workdir.append(u'D:\\wap')#增加工作目录

fy_manager.Manager.recents = []#初始化历史列表(必要，否则旧版本时将异常，除非不用历史列表)

fy_manager.Manager.set_tabs = True #当前窗口为折叠窗口(默认为False 即非折叠窗口)

app1 = appuifw.Text(u'app1')
e32.ao_yield()
app2 = appuifw.Text(u'app2')

def exit_key_handler():
  app_lock.signal()

def fy():
  path = fy_manager.Manager().AskUser()
  if path:
    fy_manager.Manager.recents.append(path) #增加历史文件(不能增加目录)

def handle_tab(index):
  if index==0:
    appuifw.app.body = app1
  elif index==1:
    appuifw.app.body = app2

appuifw.app.title = '飞影7610\nwapele.cn'.decode('utf8')

appuifw.app.set_tabs(['窗口1'.decode('utf8'), '窗口2'.decode('utf8')], handle_tab)

handle_tab(0)
appuifw.app.exit_key_handler = exit_key_handler
appuifw.app.menu = [('菜单'.decode('utf8'),fy)]

app_lock = e32.Ao_lock()
app_lock.wait()
appuifw.app.set_tabs([], None) #防止测试时异常
